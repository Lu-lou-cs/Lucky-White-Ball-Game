import random


def draw_ball(history):

    balls = ["red", "red", "red", "red", "red",
             "blue", "blue", "blue", "blue",
             "white"]

    while True:

        ball = random.choice(balls)

        # 规则1：不能出现四个连续同色
        if len(history) >= 3 and history[-1] == history[-2] == history[-3] == ball:
            continue

        # 规则2：避免一直红蓝交替
        if len(history) >= 3:
            a, b, c = history[-3], history[-2], history[-1]
            if a != b and b != c and a == c and ball == b:
                continue

        return ball


def ball_emoji(ball):

    if ball == "red":
        return "🔴"
    elif ball == "blue":
        return "🔵"
    else:
        return "⚪"


def show_box():

    print("Box contents:")
    print("🔴 🔴 🔴 🔴 🔴")
    print("🔵 🔵 🔵 🔵")
    print("⚪")
    print()


def player_turn(player_number):

    attempts = 0
    ball = ""
    history = []

    print("\nPlayer", player_number, "turn!")

    while ball != "white":

        command = input("Type D to draw a ball: ")

        if command.lower() != "d":
            print("Please type D to draw.")
            continue

        attempts += 1

        # 15次保底
        if attempts == 15:
            ball = "white"
        else:
            ball = draw_ball(history)

        history.append(ball)

        print("You drew:", ball_emoji(ball))

        if ball == "white":
            print("Great job! You got the white ball!")
        else:
            print("Sorry, you did not get the white ball. Please try again.")

    print("Player", player_number, "needed", attempts, "draw(s).\n")

    return attempts


def main():

    print("🎲 Lucky White Ball Game 🎲")
    print("Draw balls until you get the white ball.")
    print("The player who gets the white ball with the fewest draws wins!\n")

    show_box()

    p1 = player_turn(1)
    p2 = player_turn(2)
    p3 = player_turn(3)

    results = [
        ("Player 1", p1),
        ("Player 2", p2),
        ("Player 3", p3)
    ]

    results.sort(key=lambda x: x[1])

    print("\nFinal Results:")
    print("🥇 1st place:", results[0][0], "-", results[0][1], "draws")
    print("🥈 2nd place:", results[1][0], "-", results[1][1], "draws")
    print("🥉 3rd place:", results[2][0], "-", results[2][1], "draws")

    print("\nCongratulations,", results[0][0], "! You're the luckiest person!")


main()